import { useState, useRef, useEffect } from "react";
import { useAccounts } from "@/hooks/useAccounts";
import AccountManagerDialog from "@/components/AccountManagerDialog";

function AccountSwitcher() {
  const { accounts, activeAccount, switchAccount, loading } = useAccounts();
  const [open, setOpen] = useState(false);
  const [managerOpen, setManagerOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  // Close on click outside
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  const initials = activeAccount?.username?.charAt(0).toUpperCase() ?? "?";

  // Current account indicator color
  const isOffline = activeAccount?.offline ?? false;

  return (
    <>
      <div ref={ref} className="relative">
        <button
          onClick={() => setOpen(!open)}
          title={activeAccount ? activeAccount.username : "Konto"}
          className="group relative flex h-9 w-9 items-center justify-center rounded-xl bg-muted text-muted-foreground transition-colors hover:bg-accent cursor-pointer"
        >
          <span className="text-xs font-bold">{initials}</span>
          {/* Online/Offline dot */}
          <span
            className={`absolute -top-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-sidebar-background ${
              isOffline
                ? "bg-amber-500"
                : activeAccount
                  ? "bg-emerald-500"
                  : "bg-muted-foreground/30"
            }`}
          />
        </button>

        {open && (
          <div className="absolute bottom-12 left-1/2 z-50 w-56 -translate-x-1/2 mb-2 rounded-xl border border-border/50 bg-popover shadow-xl backdrop-blur-xl p-1.5">
            <div className="px-2 py-1.5 text-xs font-medium text-muted-foreground">
              {activeAccount ? "Przełącz konto" : "Konta"}
            </div>

            {loading ? (
              <div className="flex items-center justify-center py-3">
                <div className="h-4 w-4 animate-spin rounded-full border-2 border-muted border-t-purple-500" />
              </div>
            ) : accounts.length === 0 ? (
              <div className="px-2 py-3 text-xs text-muted-foreground text-center">
                Brak zapisanych kont
              </div>
            ) : (
              <div className="space-y-0.5 max-h-48 overflow-y-auto">
                {accounts.map((account) => (
                  <button
                    key={account.uuid}
                    onClick={() => {
                      switchAccount(account.uuid);
                      setOpen(false);
                    }}
                    className={`flex w-full items-center gap-2.5 rounded-lg px-2 py-2 text-sm transition-colors ${
                      account.isActive
                        ? "bg-purple-500/15 text-purple-300"
                        : "text-foreground hover:bg-accent"
                    }`}
                  >
                    <div
                      className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-xs font-bold ${
                        account.isActive
                          ? "bg-purple-500/20 text-purple-400"
                          : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {account.username.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 text-left min-w-0">
                      <div className="truncate font-medium">
                        {account.username}
                      </div>
                      <div className="text-[10px] text-muted-foreground">
                        {account.offline ? "Tryb offline" : "Konto Microsoft"}
                      </div>
                    </div>
                    {account.isActive && (
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="14"
                        height="14"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-purple-400 shrink-0"
                      >
                        <path d="M20 6 9 17l-5-5" />
                      </svg>
                    )}
                  </button>
                ))}
              </div>
            )}

            <div className="mt-1 border-t border-border/50 pt-1">
              <button
                onClick={() => {
                  setOpen(false);
                  setManagerOpen(true);
                }}
                className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-xs text-muted-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <circle cx="12" cy="12" r="10" />
                  <line x1="12" y1="8" x2="12" y2="16" />
                  <line x1="8" y1="12" x2="16" y2="12" />
                </svg>
                Zarządzaj kontami
              </button>
            </div>
          </div>
        )}
      </div>

      <AccountManagerDialog
        open={managerOpen}
        onOpenChange={setManagerOpen}
      />
    </>
  );
}

export default AccountSwitcher;
