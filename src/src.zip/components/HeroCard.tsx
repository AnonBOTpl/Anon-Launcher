import { useState } from "react";
import type { InstanceManifest } from "@/types/instance";
import { cn } from "@/lib/utils";
import { LaunchButton } from "@/components/LaunchButton";
import type { LaunchStatus } from "@/hooks/useLaunch";
import EditInstanceDialog from "@/components/EditInstanceDialog";
import DeleteInstanceDialog from "@/components/DeleteInstanceDialog";
import CloneInstanceDialog from "@/components/CloneInstanceDialog";
import ExportInstanceDialog from "@/components/ExportInstanceDialog";
import OpenFolderButton from "@/components/OpenFolderButton";

interface HeroCardProps {
  instance: InstanceManifest;
  launchStatus: LaunchStatus;
  onLaunch: () => void;
  onStop: () => void;
  canLaunch: boolean;
  onUpdated?: () => void;
  onDeleted?: () => void;
}

const loaderBadge: Record<string, { label: string; color: string }> = {
  vanilla: {
    label: "Vanilla",
    color:
      "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  },
  fabric: {
    label: "Fabric",
    color: "bg-amber-500/10 text-amber-400 border-amber-500/20",
  },
};

function HeroCard({ instance, launchStatus, onLaunch, onStop, canLaunch, onUpdated, onDeleted }: HeroCardProps) {
  const [editOpen, setEditOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [cloneOpen, setCloneOpen] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);

  const ramGB = (instance.ram / 1024).toFixed(1);
  const badge = (loaderBadge[instance.loader] ?? loaderBadge.vanilla)!;
  const loaderLabel =
    instance.loader === "fabric"
      ? `Fabric ${instance.loaderVersion}`
      : "Vanilla";

  return (
    <>
      <div className="group relative overflow-hidden rounded-2xl border border-border/50 bg-gradient-to-br from-card/90 to-card/60 p-6 md:p-8 backdrop-blur-xl transition-all duration-300 hover:border-purple-500/30 hover:shadow-xl hover:shadow-purple-500/10 animate-fade-in">
        {/* Portal glow */}
        <div className="pointer-events-none absolute -inset-px animate-portal-pulse rounded-2xl opacity-50" />

        <div className="relative flex flex-col gap-5">
          {/* Top section: icon + info + action icons row */}
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-4 min-w-0">
              {/* Icon */}
              <div className="flex h-14 w-14 shrink-0 md:h-16 md:w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-purple-500/20 to-purple-600/10 text-xl md:text-2xl font-bold text-purple-400 shadow-lg shadow-purple-500/10">
                {instance.name.charAt(0).toUpperCase()}
              </div>

              {/* Info */}
              <div className="min-w-0">
                <h1 className="text-xl md:text-2xl font-bold tracking-tight truncate">
                  {instance.name}
                </h1>
                <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1">
                  <span className="font-mono text-sm text-muted-foreground">
                    MC {instance.mcVersion}
                  </span>
                  <span className="text-muted-foreground/30 hidden sm:inline">
                    ·
                  </span>
                  <span
                    className={cn(
                      "inline-flex items-center gap-1 rounded-lg border px-2.5 py-0.5 text-xs font-medium",
                      badge.color
                    )}
                  >
                    {loaderLabel}
                  </span>
                  <span className="text-muted-foreground/30 hidden sm:inline">
                    ·
                  </span>
                  <span className="font-mono text-sm text-muted-foreground">
                    {ramGB} GB
                  </span>
                </div>
              </div>
            </div>

            {/* Play button (desktop) */}
            <div className="hidden md:block">
              <LaunchButton
                status={launchStatus}
                onLaunch={onLaunch}
                onStop={onStop}
                canLaunch={canLaunch}
                size="hero"
              />
            </div>
          </div>

          {/* Action icons row */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* Play button (mobile) */}
            <div className="md:hidden">
              <LaunchButton
                status={launchStatus}
                onLaunch={onLaunch}
                onStop={onStop}
                canLaunch={canLaunch}
                size="default"
              />
            </div>

            <div className="h-6 w-px bg-border/50 mx-1" />

            {/* Edit */}
            <button
              onClick={() => setEditOpen(true)}
              className="flex h-9 w-9 items-center justify-center rounded-xl text-muted-foreground/60 hover:text-foreground hover:bg-accent transition-all"
              title="Edytuj"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M17 3a2.83 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z" />
                <path d="m15 5 4 4" />
              </svg>
            </button>

            {/* Clone */}
            <button
              onClick={() => setCloneOpen(true)}
              className="flex h-9 w-9 items-center justify-center rounded-xl text-muted-foreground/60 hover:text-foreground hover:bg-accent transition-all"
              title="Klonuj"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
              </svg>
            </button>

            {/* Export */}
            <button
              onClick={() => setExportOpen(true)}
              className="flex h-9 w-9 items-center justify-center rounded-xl text-muted-foreground/60 hover:text-foreground hover:bg-accent transition-all"
              title="Eksportuj ZIP"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                <polyline points="7 10 12 15 17 10" />
                <line x1="12" y1="15" x2="12" y2="3" />
              </svg>
            </button>

            {/* Open folder */}
            <OpenFolderButton
              instanceName={instance.name}
              iconOnly
            />

            {/* Delete */}
            <button
              onClick={() => setDeleteOpen(true)}
              className="flex h-9 w-9 items-center justify-center rounded-xl text-muted-foreground/60 hover:text-destructive hover:bg-destructive/10 transition-all"
              title="Usuń"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M3 6h18" />
                <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Dialogs */}
      <EditInstanceDialog
        instanceName={instance.name}
        open={editOpen}
        onOpenChange={setEditOpen}
        onUpdated={onUpdated}
      />
      <DeleteInstanceDialog
        instanceName={instance.name}
        open={deleteOpen}
        onOpenChange={setDeleteOpen}
        onDeleted={onDeleted ?? onUpdated}
      />
      <CloneInstanceDialog
        sourceName={instance.name}
        open={cloneOpen}
        onOpenChange={setCloneOpen}
      />
      <ExportInstanceDialog
        instanceName={instance.name}
        open={exportOpen}
        onOpenChange={setExportOpen}
      />
    </>
  );
}

export default HeroCard;
