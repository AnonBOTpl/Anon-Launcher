import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import DeviceCodeDisplay from "@/components/DeviceCodeDisplay";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface LoginDialogProps {
  children?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

function LoginDialog({ children, open, onOpenChange }: LoginDialogProps) {
  const [internalOpen, setInternalOpen] = useState(false);
  const { session, startLogin, cancelLogin, flowState } = useAuth();

  const isOpen = open !== undefined ? open : internalOpen;
  const handleOpenChange = onOpenChange ?? setInternalOpen;

  return (
    <Dialog
      open={isOpen}
      onOpenChange={(newOpen) => {
        if (!newOpen && flowState.step !== "done") {
          cancelLogin();
        }
        handleOpenChange(newOpen);
      }}
    >
      {children && <DialogTrigger>{children}</DialogTrigger>}
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {session
              ? "Zalogowano"
              : flowState.step === "error"
                ? "Błąd logowania"
                : "Logowanie przez Microsoft"}
          </DialogTitle>
          <DialogDescription>
            {session
              ? `Jesteś zalogowany jako ${session.username}`
              : flowState.step === "error"
                ? flowState.error
                : "Zaloguj się, aby grać w Minecraft"}
          </DialogDescription>
        </DialogHeader>

        {flowState.step === "idle" && (
          <div className="flex flex-col items-center gap-6 py-6">
            {/* Microsoft logo placeholder */}
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-purple-500/10">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="32"
                height="32"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-purple-400"
              >
                <rect x="2" y="2" width="9" height="9" />
                <rect x="13" y="2" width="9" height="9" />
                <rect x="2" y="13" width="9" height="9" />
                <rect x="13" y="13" width="9" height="9" />
              </svg>
            </div>
            <p className="text-center text-sm text-muted-foreground max-w-xs">
              Kliknij poniżej, aby zalogować się przez konto Microsoft.
              Zostaniesz przekierowany do przeglądarki.
            </p>
            <Button
              onClick={startLogin}
              className="w-full bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-400 text-white shadow-lg shadow-purple-500/20"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="currentColor"
                className="mr-2"
              >
                <rect x="2" y="2" width="9" height="9" />
                <rect x="13" y="2" width="9" height="9" />
                <rect x="2" y="13" width="9" height="9" />
                <rect x="13" y="13" width="9" height="9" />
              </svg>
              Zaloguj przez Microsoft
            </Button>
          </div>
        )}

        {(flowState.step === "code" || flowState.step === "polling") &&
          flowState.deviceCode && (
            <DeviceCodeDisplay
              deviceCode={flowState.deviceCode}
              onCancel={cancelLogin}
            />
          )}

        {flowState.step === "completing" && (
          <div className="flex flex-col items-center gap-4 py-8">
            <div className="h-10 w-10 animate-spin rounded-full border-4 border-muted border-t-purple-500" />
            <p className="text-sm text-muted-foreground">
              Autoryzacja... Pobieranie profilu Minecraft
            </p>
          </div>
        )}

        {flowState.step === "done" && session && (
          <div className="flex flex-col items-center gap-4 py-6">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-500/10">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="32"
                height="32"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-emerald-400"
              >
                <path d="M20 6 9 17l-5-5" />
              </svg>
            </div>
            <div className="text-center">
              <p className="font-semibold">{session.username}</p>
              <p className="text-xs text-muted-foreground font-mono mt-1">
                {session.uuid}
              </p>
            </div>
          </div>
        )}

        {flowState.step === "error" && (
          <div className="flex flex-col items-center gap-4 py-4">
            <div className="rounded-lg border border-destructive/50 bg-destructive/10 p-3 text-sm text-destructive w-full text-center">
              {flowState.error || "Wystąpił błąd podczas logowania"}
            </div>
            <Button
              onClick={startLogin}
              variant="outline"
              className="w-full"
            >
              Spróbuj ponownie
            </Button>
          </div>
        )}

        {flowState.step === "done" && session && (
          <div className="flex justify-center pb-2">
            <Button
              variant="outline"
              onClick={() => handleOpenChange(false)}
            >
              Zamknij
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

export default LoginDialog;
