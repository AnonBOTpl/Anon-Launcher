import { useState } from "react";
import { useSettings } from "@/hooks/useSettings";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface SettingsDialogProps {
  children?: React.ReactNode;
}

function SettingsDialog({ children }: SettingsDialogProps) {
  const [internalOpen, setInternalOpen] = useState(false);
  const { clientId: savedClientId, setClientId: saveClientId } = useSettings();
  const [localClientId, setLocalClientId] = useState(savedClientId);

  const handleSave = () => {
    saveClientId(localClientId);
    setInternalOpen(false);
  };

  const handleOpenChange = (open: boolean) => {
    if (open) {
      setLocalClientId(savedClientId);
    }
    setInternalOpen(open);
  };

  return (
    <Dialog open={internalOpen} onOpenChange={handleOpenChange}>
      {children && <DialogTrigger>{children}</DialogTrigger>}
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Ustawienia</DialogTitle>
          <DialogDescription>
            Skonfiguruj własny Client ID dla logowania Microsoft
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col gap-4 py-2">
          <div className="flex flex-col gap-1.5">
            <label
              htmlFor="client-id"
              className="text-xs font-medium text-muted-foreground"
            >
              Microsoft Client ID
            </label>
            <Input
              id="client-id"
              type="text"
              placeholder="550e8400-e29b-41d4-a716-446655440000"
              value={localClientId}
              onChange={(e) => setLocalClientId(e.target.value)}
            />
            <p className="text-xs text-muted-foreground/70 mt-1">
              {localClientId
                ? "Własny Client ID — aplikacja musi być zatwierdzona przez Microsoft dla Minecraft"
                : "Puste = domyślny Client ID (może nie działać dla Minecraft)"}
            </p>
          </div>

          <div className="flex flex-col gap-2 rounded-lg border border-border/50 bg-muted/30 p-3">
            <p className="text-xs font-medium text-muted-foreground">
              Jak zdobyć własny Client ID?
            </p>
            <ol className="flex flex-col gap-1 pl-4 text-xs text-muted-foreground/70 list-decimal">
              <li>
                Wejdź na{" "}
                <a
                  href="https://portal.azure.com/#view/Microsoft_AAD_RegisteredApps/ApplicationsListBlade"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-purple-400 hover:underline"
                >
                  portal Azure
                </a>
              </li>
              <li>Zarejestruj nową aplikację (konto osobiste Microsoft)</li>
              <li>Włącz "Allow public client flows" w zakładce Authentication</li>
              <li>Skopiuj Application (client) ID i wklej tutaj</li>
              <li>
                Złóż wniosek na{" "}
                <a
                  href="https://aka.ms/mce-reviewappid"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-purple-400 hover:underline"
                >
                  aka.ms/mce-reviewappid
                </a>{" "}
                aby odblokować Minecraft
              </li>
            </ol>
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-2">
          <Button
            variant="ghost"
            onClick={() => {
              setLocalClientId(savedClientId);
              setInternalOpen(false);
            }}
          >
            Anuluj
          </Button>
          <Button onClick={handleSave}>Zapisz</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default SettingsDialog;
